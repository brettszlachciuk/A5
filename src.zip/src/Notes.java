public class Notes {
  //Focus only on storing shapes, adding shapes to animation, getting the positions of all shapes
  //in the animation, and making sure there are no incorrect states added to the animation
  //such as contradictory states for a certain shape etc.
  //Motion interface with beginning and end attributes. motion must have shape nd

  //IModel:
  //either void addShape(String id, String Shape)
  //void addRectangle(int... attributes)
  //List<IShape> getallShapesAytFrame();
  //List<String> getallshapeIDs();
}
